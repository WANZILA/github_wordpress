
<h2 class="text-edit">ENTRY REQUIREMENTS</h2>
<h3 class="text-edit3">For  Diploma</h3>                    
<ol>  
  <li>O-Level and A-level certificate with at least 1 principle pass </li>
  <li>Certificate from a recognized institution or its equivalent </li>
</ol> 
<h3 class="text-edit3">For  Certificate</h3>                    
<ol>  
    <li>O-Level certificate with at least 3 passes or its Equivalent </li>
</ol> 

<h2 class="text-edit">APPLICATON FORMs</h2>
<ol>  
    <li><a href="../../../assets/PTC_Application_forms_theology.pdf" target="_blank">Department of Theology</a></li>
    <li><a href="../../../assets/PTC_Application_form _Community_Transformation.pdf" target="_blank">Department of Community Transformation </a></li>
</ol> 
                      
<h2 class="text-edit">FUNCTIONAL FEES</h2>
<ol>
  <li><a  href="../../../assets/Modular-Fees_Structure.pdf"> Modular Functional fees</a> per Session</li>
  <li><a  href="../../../assets/FEE_STRUCTURE_fultime_theology.pdf" target="_blank"> Full 
  Department of Theology</a> per Session</li> 
  <!-- <li><a  href="../../../assets/Fees_StructureCommuninity_Transformation.pdf" target="_blank" > Department of Community Transformation</a> per Semester<br></li> -->
  <li><a  href="../../../assets/UBTEB_FEE_STRUCTURE.pdf" target="_blank" > Department of Community Transformation</a> per Semester<br></li>
</ol>




