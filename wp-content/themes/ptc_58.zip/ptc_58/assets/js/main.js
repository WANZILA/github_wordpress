// alert('hellow');

// let dropDown = document.getElementById("menu-item-dropdown-212");

// dropDown.addEventListener("mouseenter",function(event){
//   event.target.style.display ="block";
//   event.target.style.color ="black";
// });
/*  rs on getting dorpdown -menu by mouse enter main nav 
.dropdown-menu:hover {
  position: absolute;
  display: block;
}

*/
let studentResource = document.getElementById('menu-item-212');
studentResource.addEventListener("mouseenter",function(){
  alert('hih');
  console.log('eeeee');
});